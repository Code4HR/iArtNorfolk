<?php

header('Location: public/index.html#list-page');

?>
