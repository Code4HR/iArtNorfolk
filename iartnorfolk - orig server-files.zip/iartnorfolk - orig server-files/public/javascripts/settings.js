var Muralapp = {
    google_analytics : 'UA-XXXXXXXX-X',
    db : {
        //path : 'http://yourcouch.com:5984/murals'
		//path : 'http://wazzow.com/iartnorfolk/public/javascripts/sample_data_norfolk.js'
		path: '/iartnorfolk/data.php'
    }
}
