var Muralapp = {
    google_analytics : 'UA-XXXXXXXX-X',
    db : {
        path : 'http://yourcouch.com:5984/murals'
    }
}