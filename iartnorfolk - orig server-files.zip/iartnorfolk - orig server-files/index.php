<?php

header('Location: public');

?>
